--CS158A --Group Project --Mini Banking System with DB2 JDBC
--Group Names: 
--Andrew Fidel(008313708), Itaru Kishikawa(011165193), Ryan Woo(004067233), & Tyler Veeman(010511735).

--Setup DB2, see Download Instructions.txt
--Create database named "CS158A", you can run command lines below in DB2 CLP
--db2 create database CS158A /* assume successfully created so run command below */
--db2 connect to CS158A /* now you have created & connected to database "CS158A" */
--Assume that the database exists before the application is run,

The schema is created on the first run 
by running a test query selecting from the customer table. 
The schema is either there completely or not, if it is partially there 
then a manual drop is required so on first run the schema is generated.
DB2 CLP -> db2 -tvf drop.sql

The script that generates the schema is create.sql, 
I then pass through a command to remove all newlines and put in the 
bank properties so it will be run on the first application run.

Some useful command lines
==========================
// in Linux or Mac?
generate one liner query for properties:
tr -d '\n' < create.sql
// in Windows
use notepad to open a file. Notepad, a text file with multiple lines of text 
appears concatenated into a single line because of 2 char: carriage return.
PowerShell in directories >>>(gc create.sql) -join ''

// compile and run in one line (linux shell): or Mac (Terminal)
javac bank.java && java -cp :./db2jcc4.jar bank bank.properties
// compile and run in one line (Windows cmd):
javac bank.java && java bank bank.properties

drop.sql is list of commands that can be copy pasted on the interactive db2 shell 
to drop everything Starting from a fresh database either run each SQL statement.
db2 DROP TABLE P1.Customer
db2 DROP TABLE P1.Account
db2 DROP VIEW  P1.CustomerAccountsSummary
(or)
db2 -tvf drop.sql
(or)
db2 drop database CS158A 
// if you cannot drop (delete) database, try command lines below in order
db2 quiesce db immediate force connections
db2 connect reset
db2 terminate
db2 force application all
db2stop
db2start
db2 drop database CS158A

/////////////////////////////////////////////////////////////////////////////////

Sample run:

C:\Program Files\IBM\SQLLIB\BIN>cd C:\Users\Dell\Desktop\GroupProjectCS158A\bank

C:\Users\Dell\Desktop\GroupProjectCS158A\bank>javac bank.java && java bank bank.properties

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 1
Name: Andrew
Gender M (or) F: M
Age (Number Only): 20
Pin (Number Only): 1111
Customer successfully created:
Name: Andrew, Gender: M, Age: 20, Pin: 1111
Customer ID: #100

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 1
Name: Ryan
Gender M (or) F: M
Age (Number Only): 21
Pin (Number Only): 2222
Customer successfully created:
Name: Ryan, Gender: M, Age: 21, Pin: 2222
Customer ID: #101

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 2
ID: 100
Pin: 1111

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Andrew (#100)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 1
Customer ID (Yours is #100): 100
Account type [C]hecking/[S]avings: C
Initial deposit: 125
Account successfully created!
Customer ID: 100, Status: A, Type: C
Account no:1000

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Andrew (#100)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 3
Account no: 1000
Deposit amount: 225
Deposit successful

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Andrew (#100)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 6
Account summary for Customer with ID: 100
#1000 - 350 $
Total: 350 $

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Andrew (#100)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 7

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 2
ID: 101
Pin: 2222

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Ryan (#101)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 1
Customer ID (Yours is #101): 101
Account type [C]hecking/[S]avings: C
Initial deposit: 550
Account successfully created!
Customer ID: 101, Status: A, Type: C
Account no:1001

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Ryan (#101)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 4
Account no: 1001
Withdrawal amount: 115
Withdraw successful

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Ryan (#101)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 6
Account summary for Customer with ID: 101
#1001 - 435 $
Total: 435 $

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Ryan (#101)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 6
Account summary for Customer with ID: 101
#1001 - 435 $
Total: 435 $

CS158A Mini Banking System - Customer Menu
--------------------------------------------------------

Welcome Ryan (#101)
1. Open Account
2. Close Account
3. Deposit
4. Withdraw
5. Transfer
6. Account Summary
7. Exit

Your choice: 7

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 2
ID: 0
Pin: 0

CS158A Mini Banking System - Administrator Main Menu
--------------------------------------------------------

1. Account Summary for a Customer
2. Report A :: Customer information with total Balance in Decreasing Order
3. Report B :: Find the Average Total Balance Between Age Groups
4. Exit

Your choice: 2
Report A :: Customer information with total Balance in Decreasing Order
-----------------------------------------------------------------------

#101: Ryan  M 21yrs old, Total Balance: 435 $
#100: Andrew  M 20yrs old, Total Balance: 350 $

CS158A Mini Banking System - Administrator Main Menu
--------------------------------------------------------

1. Account Summary for a Customer
2. Report A :: Customer information with total Balance in Decreasing Order
3. Report B :: Find the Average Total Balance Between Age Groups
4. Exit

Your choice: 4

Welcome to the CS158A mini banking system! - Main Menu
--------------------------------------------------------

1. New Customer
2. Customer Login
3. Exit

Your choice: 3
Thanks for using the CS158A mini banking system!

C:\Users\Dell\Desktop\GroupProjectCS158A\bank>