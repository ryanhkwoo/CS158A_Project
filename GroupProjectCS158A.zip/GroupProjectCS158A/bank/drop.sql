--CS158A Group Project
--Group Names: 
--Andrew Fidel(008313708), Itaru Kishikawa(011165193), Ryan Woo(004067233), & Tyler Veeman(010511735).
DROP TABLE Customer;
DROP TABLE Account;
DROP VIEW  CustomerAccountsSummary;
